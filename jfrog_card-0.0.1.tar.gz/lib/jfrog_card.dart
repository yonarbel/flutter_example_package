library jfrogfluttercontainer;

export 'src/jfrog_flutter_container.dart';